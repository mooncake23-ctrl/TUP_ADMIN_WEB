import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class CreateUserScreen extends StatefulWidget {
  @override
  _CreateUserScreenState createState() => _CreateUserScreenState();
}

class _CreateUserScreenState extends State<CreateUserScreen> {
  final _formKey = GlobalKey<FormState>();
  bool _isUploading = false;
  final Color primaryColor = Color(0xFF71BFDC);
  final Color backgroundColor = Colors.grey[50]!;

  // Controllers for form fields
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController rfidController = TextEditingController();
  TextEditingController roleController = TextEditingController(text: 'user');
  TextEditingController assignedSlotController = TextEditingController();
  TextEditingController phoneNumberController = TextEditingController();
  TextEditingController fullnameController = TextEditingController();
  TextEditingController idNumberController = TextEditingController();
  TextEditingController plateNumberController = TextEditingController();
  TextEditingController vehicleTypeController = TextEditingController();
  TextEditingController vehicleModelController = TextEditingController();

  bool _obscurePassword = true;

  void _resetForm() {
    setState(() {
      emailController.clear();
      passwordController.clear();
      rfidController.clear();
      roleController.text = 'user';
      assignedSlotController.clear();
      phoneNumberController.clear();
      fullnameController.clear();
      idNumberController.clear();
      plateNumberController.clear();
      vehicleTypeController.clear();
      vehicleModelController.clear();
    });
  }

  Future<void> _createUser() async {
    if (_formKey.currentState!.validate()) {
      setState(() => _isUploading = true);

      try {
        // First create the user
        final userData = {
          "email": emailController.text.trim(),
          "name": emailController.text.trim(),
          "password_hash": passwordController.text.trim(),
          "rfid": rfidController.text.trim(),
          "role": roleController.text.trim(),
          "assignedslot": assignedSlotController.text.trim().isEmpty
              ? "n/a"
              : assignedSlotController.text.trim(),
        };

        final userResponse = await http.post(
          Uri.parse('https://appfinity.vercel.app/users/add'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode(userData),
        );

        if (userResponse.statusCode >= 200 && userResponse.statusCode < 300) {
          // Then create the profile
          final profileData = {
            "name": emailController.text.trim(),
            "full_name": fullnameController.text.trim(),
            "id_number": idNumberController.text.trim(),
            "plate_number": plateNumberController.text.trim(),
            "vehicle_model": vehicleModelController.text.trim(),
            "vehicle_type": vehicleTypeController.text.trim(),
            "image_link": "",
            "phone_number": phoneNumberController.text.trim(),
          };

          final profileResponse = await http.post(
            Uri.parse('https://appfinity.vercel.app/profile/add'),
            headers: {
              'Content-Type': 'application/json',
              'accept': 'application/json',
            },
            body: jsonEncode(profileData),
          );

          if (profileResponse.statusCode >= 200 && profileResponse.statusCode < 300) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('User created successfully!'),
                backgroundColor: Colors.green,
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            );
            _resetForm();
          } else {
            throw Exception('Profile creation failed: ${profileResponse.body}');
          }
        } else {
          throw Exception('User creation failed: ${userResponse.body}');
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        );
      } finally {
        setState(() => _isUploading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        title: Text(
          'Create New User',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        backgroundColor: primaryColor,
        elevation: 0,
        actions: [
          IconButton(
            icon: Icon(Icons.refresh, color: Colors.white),
            onPressed: _resetForm,
            tooltip: 'Reset Form',
          ),
        ],
      ),
      body: Container(
        color: Colors.grey[200], // Light grey background
        child: SingleChildScrollView(
          padding: EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Account Information Card
                _buildSectionCard(
                  title: 'Account Information',
                  icon: Icons.account_circle,
                  children: [
                    _buildTextField(emailController, 'Email', Icons.email),
                    SizedBox(height: 12),
                    _buildPasswordField(),
                    SizedBox(height: 12),
                    _buildTextField(rfidController, 'RFID', Icons.credit_card),
                    SizedBox(height: 12),
                    _buildTextField(phoneNumberController, 'Phone', Icons.phone),
                    SizedBox(height: 12),
                    _buildTextField(
                      assignedSlotController,
                      'Assigned Slot (optional)',
                      Icons.local_parking,
                      required: false,
                    ),
                  ],
                ),

                SizedBox(height: 20),

                // Profile Information Card
                _buildSectionCard(
                  title: 'Profile Information',
                  icon: Icons.person_outline,
                  children: [
                    _buildTextField(fullnameController, 'Full Name', Icons.person),
                    SizedBox(height: 12),
                    _buildTextField(idNumberController, 'ID Number', Icons.badge),
                    SizedBox(height: 12),
                    _buildTextField(plateNumberController, 'Plate Number', Icons.directions_car),
                    SizedBox(height: 12),
                    _buildTextField(vehicleTypeController, 'Vehicle Type', Icons.directions_car),
                    SizedBox(height: 12),
                    _buildTextField(vehicleModelController, 'Vehicle Model', Icons.directions_car),
                  ],
                ),

                SizedBox(height: 30),

                // Submit Button
                Center(
                  child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _isUploading ? null : _createUser ,
                      child: _isUploading
                          ? SizedBox(
                        height: 24,
                        width: 24,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 2,
                        ),
                      )
                          : Text(
                        'CREATE USER',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: primaryColor,
                        padding: EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        elevation: 2,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSectionCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      color: Colors.white, // Light background for the card
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: primaryColor, size: 24), // Keep primaryColor for icon
                SizedBox(width: 8),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800], // Dark text for contrast on light bg
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(
      TextEditingController controller,
      String label,
      IconData icon, {
        bool required = true,
      }) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: Colors.grey[600]),
        prefixIcon: Icon(icon, color: primaryColor),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: primaryColor, width: 2),
        ),
        filled: true,
        fillColor: Colors.white,
        contentPadding: EdgeInsets.symmetric(vertical: 14, horizontal: 16),
      ),
      style: TextStyle(color: Colors.grey[800]),
      validator: required
          ? (value) => value!.isEmpty ? '$label is required' : null
          : null,
    );
  }

  Widget _buildPasswordField() {
    return TextFormField(
      controller: passwordController,
      obscureText: _obscurePassword,
      decoration: InputDecoration(
        labelText: 'Password',
        labelStyle: TextStyle(color: Colors.grey[600]),
        prefixIcon: Icon(Icons.lock, color: primaryColor),
        suffixIcon: IconButton(
          icon: Icon(
            _obscurePassword ? Icons.visibility : Icons.visibility_off,
            color: primaryColor,
          ),
          onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: primaryColor, width: 2),
        ),
        filled: true,
        fillColor: Colors.white,
        contentPadding: EdgeInsets.symmetric(vertical: 14, horizontal: 16),
      ),
      style: TextStyle(color: Colors.grey[800]),
      validator: (value) => value!.isEmpty ? 'Password is required' : null,
    );
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    rfidController.dispose();
    roleController.dispose();
    assignedSlotController.dispose();
    phoneNumberController.dispose();
    fullnameController.dispose();
    idNumberController.dispose();
    plateNumberController.dispose();
    vehicleTypeController.dispose();
    vehicleModelController.dispose();
    super.dispose();
  }
}